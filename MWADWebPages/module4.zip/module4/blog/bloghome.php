<?php
{
echo "<htmL><head>";
echo "</head><body>";
echo "<p>This is a PHP paragraph</p>";
echo "</body></html>";
};
?>
